import timeit


# ----------------------------
# RECURSIVE FUNCTIONS
# ----------------------------

def recursive_sum(n):
    if n == 1:
        return 1
    return n + recursive_sum(n - 1)


def recursive_fibonacci(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    return recursive_fibonacci(n - 1) + recursive_fibonacci(n - 2)


def recursive_factorial(n):
    if n == 0:
        return 1
    return n * recursive_factorial(n - 1)


# ----------------------------
# ITERATIVE FUNCTIONS
# ----------------------------

def iterative_sum(n):
    total = 0
    for i in range(1, n + 1):
        total += i
    return total


def iterative_fibonacci(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1

    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b


def iterative_factorial(n):
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result


# ----------------------------
# TEST OUTPUTS
# ----------------------------

print("SUM TEST")
print("Recursive sum of 5:", recursive_sum(5))
print("Iterative sum of 5:", iterative_sum(5))

print("\nFIBONACCI TEST")
print("Recursive fibonacci of 7:", recursive_fibonacci(7))
print("Iterative fibonacci of 7:", iterative_fibonacci(7))

print("\nFACTORIAL TEST")
print("Recursive factorial of 5:", recursive_factorial(5))
print("Iterative factorial of 5:", iterative_factorial(5))


# ----------------------------
# TIME COMPARISON
# ----------------------------

print("\nTIME COMPARISON")

sum_rec_time = timeit.timeit(lambda: recursive_sum(100), number=1000)
sum_itr_time = timeit.timeit(lambda: iterative_sum(100), number=1000)

fib_rec_time = timeit.timeit(lambda: recursive_fibonacci(20), number=10)
fib_itr_time = timeit.timeit(lambda: iterative_fibonacci(20), number=10)

fact_rec_time = timeit.timeit(lambda: recursive_factorial(20), number=1000)
fact_itr_time = timeit.timeit(lambda: iterative_factorial(20), number=1000)

print(f"Recursive Sum time: {sum_rec_time:.6f} seconds")
print(f"Iterative Sum time: {sum_itr_time:.6f} seconds")

print(f"Recursive Fibonacci time: {fib_rec_time:.6f} seconds")
print(f"Iterative Fibonacci time: {fib_itr_time:.6f} seconds")

print(f"Recursive Factorial time: {fact_rec_time:.6f} seconds")
print(f"Iterative Factorial time: {fact_itr_time:.6f} seconds") 