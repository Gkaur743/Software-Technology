import time
import random

# Simple BST Node
class Node:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None

# BST insert
def insert_bst(root, key):
    if root is None:
        return Node(key)
    if key < root.key:
        root.left = insert_bst(root.left, key)
    else:
        root.right = insert_bst(root.right, key)
    return root

# BST search
def search_bst(root, key):
    if root is None or root.key == key:
        return root
    if key < root.key:
        return search_bst(root.left, key)
    return search_bst(root.right, key)

# AVL Node
class AVLNode:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None
        self.height = 1

def height(node):
    return node.height if node else 0

def get_balance(node):
    return height(node.left) - height(node.right) if node else 0

def right_rotate(z):
    y = z.left
    t3 = y.right

    y.right = z
    z.left = t3

    z.height = 1 + max(height(z.left), height(z.right))
    y.height = 1 + max(height(y.left), height(y.right))
    return y

def left_rotate(z):
    y = z.right
    t2 = y.left

    y.left = z
    z.right = t2

    z.height = 1 + max(height(z.left), height(z.right))
    y.height = 1 + max(height(y.left), height(y.right))
    return y

def insert_avl(node, key):
    if not node:
        return AVLNode(key)

    if key < node.key:
        node.left = insert_avl(node.left, key)
    else:
        node.right = insert_avl(node.right, key)

    node.height = 1 + max(height(node.left), height(node.right))
    balance = get_balance(node)

    if balance > 1 and key < node.left.key:
        return right_rotate(node)
    if balance < -1 and key > node.right.key:
        return left_rotate(node)

    return node

# Benchmark function
def benchmark(n):
    values = [random.randint(1, 1000) for _ in range(n)]

    # BST
    bst_root = None
    start = time.time()
    for v in values:
        bst_root = insert_bst(bst_root, v)
    bst_insert = time.time() - start

    start = time.time()
    for v in values:
        search_bst(bst_root, v)
    bst_search = time.time() - start

    # AVL
    avl_root = None
    start = time.time()
    for v in values:
        avl_root = insert_avl(avl_root, v)
    avl_insert = time.time() - start

    start = time.time()
    for v in values:
        search_bst(avl_root, v)
    avl_search = time.time() - start

    print(f"\nResults for {n} elements:")
    print(f"BST Insert Time: {bst_insert:.6f}")
    print(f"BST Search Time: {bst_search:.6f}")
    print(f"AVL Insert Time: {avl_insert:.6f}")
    print(f"AVL Search Time: {avl_search:.6f}")

# Run tests
benchmark(1000)
benchmark(5000) 