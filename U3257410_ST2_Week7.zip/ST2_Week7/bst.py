class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None


def preorder(root):
    if root:
        print(root.value, end=' ')
        preorder(root.left)
        preorder(root.right)


def inorder(root):
    if root:
        inorder(root.left)
        print(root.value, end=' ')
        inorder(root.right)


def postorder(root):
    if root:
        postorder(root.left)
        postorder(root.right)
        print(root.value, end=' ')


def insert_bst(root, val):
    if root is None:
        return Node(val)
    if val < root.value:
        root.left = insert_bst(root.left, val)
    else:
        root.right = insert_bst(root.right, val)
    return root


def search_bst(root, val):
    if root is None or root.value == val:
        return root
    if val < root.value:
        return search_bst(root.left, val)
    else:
        return search_bst(root.right, val)


def count_nodes(root):
    if root is None:
        return 0
    return 1 + count_nodes(root.left) + count_nodes(root.right)


def height(root):
    if root is None:
        return 0
    return 1 + max(height(root.left), height(root.right))


def find_min(root):
    current = root
    while current.left:
        current = current.left
    return current


def delete_node(root, val):
    if root is None:
        return root

    if val < root.value:
        root.left = delete_node(root.left, val)
    elif val > root.value:
        root.right = delete_node(root.right, val)
    else:
        if root.left is None:
            return root.right
        elif root.right is None:
            return root.left

        temp = find_min(root.right)
        root.value = temp.value
        root.right = delete_node(root.right, temp.value)

    return root


from collections import deque

def level_order(root):
    if not root:
        return
    queue = deque([root])
    while queue:
        node = queue.popleft()
        print(node.value, end=' ')
        if node.left:
            queue.append(node.left)
        if node.right:
            queue.append(node.right)


root = None

values = [10, 5, 15, 3, 7, 12, 18]
for v in values:
    root = insert_bst(root, v)

print("Preorder:")
preorder(root)

print("\nInorder:")
inorder(root)

print("\nPostorder:")
postorder(root)

print("\nLevel order:")
level_order(root)

print("\n\nTotal nodes:", count_nodes(root))
print("Height:", height(root))

# Search example
search_value = 7
result = search_bst(root, search_value)
if result:
    print(f"Value {search_value} found in BST.")
else:
    print(f"Value {search_value} not found in BST.")

# Delete example
print("\nDeleting 10...")
root = delete_node(root, 10)

print("Inorder after deletion:")
inorder(root)
print() 

root = Node(10)
root.left = Node(5)
root.right = Node(15)
root.left.left = Node(3)
root.left.right = Node(7)
root.right.right = Node(18)

print("Preorder traversal:")
preorder(root)
print()

print("Inorder traversal:")
inorder(root)
print()

print("Postorder traversal:") 
postorder(root)
print()

print("Total number of nodes:")
print(count_nodes(root))

print("Height of tree:")
print(height(root))

print("Search for 7:")
result = search_bst(root, 7)
if result:
    print("Found:", result.value)
else:
    print("Not found")

print("Insert 12:")
root = insert_bst(root, 12)
inorder(root)
print()

print("Delete 5:")
root = delete_node(root, 5)
inorder(root)
print()

print("Level order traversal:")
level_order(root)
print()