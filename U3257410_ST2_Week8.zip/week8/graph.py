class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph:
            self.graph[vertex1].append(vertex2)

            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight

            if not self.directed:
                self.graph[vertex2].append(vertex1)

                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def remove_vertex(self, vertex):
        if vertex in self.graph:
            del self.graph[vertex]

            for v in self.graph:
                if vertex in self.graph[v]:
                    self.graph[v].remove(vertex)

            if self.weighted:
                keys_to_remove = []
                for edge in self.weights:
                    if vertex in edge:
                        keys_to_remove.append(edge)
                for edge in keys_to_remove:
                    del self.weights[edge]

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph[vertex1]:
            self.graph[vertex1].remove(vertex2)

        if self.weighted and (vertex1, vertex2) in self.weights:
            del self.weights[(vertex1, vertex2)]

        if not self.directed:
            if vertex2 in self.graph and vertex1 in self.graph[vertex2]:
                self.graph[vertex2].remove(vertex1)

            if self.weighted and (vertex2, vertex1) in self.weights:
                del self.weights[(vertex2, vertex1)]

    def print_graph(self):
        for vertex in self.graph:
            if self.weighted:
                connections = []
                for neighbor in self.graph[vertex]:
                    weight = self.weights.get((vertex, neighbor), 0)
                    connections.append(f"{neighbor}({weight})")
                print(f"{vertex} -> {connections}")
            else:
                print(f"{vertex} -> {self.graph[vertex]}")

    def bfs(self, start):
        visited = []
        queue = [start]

        while queue:
            vertex = queue.pop(0)
            if vertex not in visited:
                visited.append(vertex)
                for neighbor in self.graph[vertex]:
                    if neighbor not in visited and neighbor not in queue:
                        queue.append(neighbor)

        return visited

    def dfs(self, start):
        visited = []
        stack = [start]

        while stack:
            vertex = stack.pop()
            if vertex not in visited:
                visited.append(vertex)
                for neighbor in reversed(self.graph[vertex]):
                    if neighbor not in visited:
                        stack.append(neighbor)

        return visited

    def has_undirected_cycle(self):
        visited = set()

        def dfs_cycle(vertex, parent):
            visited.add(vertex)

            for neighbor in self.graph[vertex]:
                if neighbor not in visited:
                    if dfs_cycle(neighbor, vertex):
                        return True
                elif neighbor != parent:
                    return True

            return False

        for vertex in self.graph:
            if vertex not in visited:
                if dfs_cycle(vertex, None):
                    return True

        return False 