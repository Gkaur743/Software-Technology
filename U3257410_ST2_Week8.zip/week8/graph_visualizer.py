from graph import Graph
import tkinter as tk
import math

class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()
        self.title("Graph Visualizer")
        self.geometry("500x500")
        self.graph = graph

        self.canvas = tk.Canvas(self, width=450, height=450, bg="white")
        self.canvas.pack(pady=20)

        self.vertex_positions = {}
        self.draw_graph()

    def draw_graph(self):
        self.canvas.delete("all")

        radius = 20
        spacing = 140
        n = len(self.graph.graph)

        if n == 0:
            return

        angle_gap = 360 / n
        center_x, center_y = 225, 225

        vertices = list(self.graph.graph.keys())

        # Draw vertices in a circle
        for i, vertex in enumerate(vertices):
            angle = math.radians(i * angle_gap)
            x = center_x + spacing * math.cos(angle)
            y = center_y + spacing * math.sin(angle)
            self.vertex_positions[vertex] = (x, y)

            self.canvas.create_oval(
                x - radius, y - radius,
                x + radius, y + radius,
                fill="lightblue"
            )
            self.canvas.create_text(x, y, text=vertex, font=("Arial", 12, "bold"))

        # Draw edges
        for vertex in vertices:
            x1, y1 = self.vertex_positions[vertex]
            for neighbor in self.graph.graph[vertex]:
                x2, y2 = self.vertex_positions[neighbor]

                if self.graph.directed:
                    self.canvas.create_line(x1, y1, x2, y2, arrow=tk.LAST, width=2)
                else:
                    self.canvas.create_line(x1, y1, x2, y2, width=2)

                if self.graph.weighted:
                    weight = self.graph.weights.get((vertex, neighbor), "")
                    mid_x = (x1 + x2) / 2
                    mid_y = (y1 + y2) / 2
                    self.canvas.create_text(mid_x, mid_y, text=str(weight), fill="red")

if __name__ == "__main__":
    g = Graph(directed=True, weighted=True)

    g.add_vertex("A")
    g.add_vertex("B")
    g.add_vertex("C")
    g.add_vertex("D")

    g.add_edge("A", "B", 10)
    g.add_edge("B", "C", 20)
    g.add_edge("C", "D", 30)
    g.add_edge("A", "D", 40)

    app = GraphVisualizer(g)
    app.mainloop() 