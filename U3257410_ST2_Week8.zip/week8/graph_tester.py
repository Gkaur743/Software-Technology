from graph import Graph

print("----- Basic Undirected Graph -----")
g = Graph()
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')

print("After adding vertices:")
g.print_graph()
print()

g.add_edge('A', 'B')
g.add_edge('A', 'C')
g.add_edge('B', 'D')
g.add_edge('C', 'D')

print("After adding edges:")
g.print_graph()
print()

g.remove_edge('A', 'B')
print("After removing edge A-B:")
g.print_graph()
print()

g.remove_vertex('D')
print("After removing vertex D:")
g.print_graph()
print()


print("----- Directed Graph -----")
dg = Graph(directed=True)
dg.add_vertex('A')
dg.add_vertex('B')
dg.add_vertex('C')
dg.add_vertex('D')

dg.add_edge('A', 'B')
dg.add_edge('B', 'C')
dg.add_edge('C', 'D')

dg.print_graph()
print()


print("----- Weighted Directed Graph -----")
wg = Graph(directed=True, weighted=True)
wg.add_vertex('A')
wg.add_vertex('B')
wg.add_vertex('C')

wg.add_edge('A', 'B', 15)
wg.add_edge('B', 'C', 34)
wg.add_edge('A', 'C', 50)

wg.print_graph()
print()


print("----- BFS -----")
bfs_graph = Graph()
for v in ['A', 'B', 'C', 'D']:
    bfs_graph.add_vertex(v)

bfs_graph.add_edge('A', 'B')
bfs_graph.add_edge('A', 'C')
bfs_graph.add_edge('B', 'D')
bfs_graph.add_edge('C', 'D')

visited_bfs = bfs_graph.bfs('A')
print("BFS starting from vertex 'A':")
print("Visited vertices in BFS order:", visited_bfs)
print()


print("----- DFS -----")
visited_dfs = bfs_graph.dfs('A')
print("DFS starting from vertex 'A':")
print("Visited vertices in DFS order:", visited_dfs)
print()


print("----- Cycle Detection -----")

# Graph with cycle
cycle_graph = Graph(directed=False)
for v in ['A', 'B', 'C']:
    cycle_graph.add_vertex(v)

cycle_graph.add_edge('A', 'B')
cycle_graph.add_edge('B', 'C')
cycle_graph.add_edge('C', 'A')

print("Does cycle_graph have a cycle?", cycle_graph.has_undirected_cycle())

# Graph without cycle
acyclic_graph = Graph(directed=False)
for v in ['X', 'Y', 'Z']:
    acyclic_graph.add_vertex(v)

acyclic_graph.add_edge('X', 'Y')
acyclic_graph.add_edge('Y', 'Z')

print("Does acyclic_graph have a cycle?", acyclic_graph.has_undirected_cycle())
print() 