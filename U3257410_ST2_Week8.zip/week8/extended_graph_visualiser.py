from graph import Graph
import tkinter as tk
import math
import time

class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()
        self.title("Extended Graph Visualiser")
        self.geometry("700x700")
        self.graph = graph

        self.canvas = tk.Canvas(self, width=600, height=600, bg="white")
        self.canvas.pack(pady=10)

        self.vertex_positions = {}
        self.vertex_circles = {}
        self.edge_lines = {}
        self.node_radius = 20
        self.spacing = 200
        self.center = (300, 300)

        control_frame = tk.Frame(self)
        control_frame.pack()

        tk.Button(control_frame, text="Run BFS", command=self.run_bfs).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Run DFS", command=self.run_dfs).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Detect Undirected Cycle", command=self.detect_undirected_cycle).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Detect Directed Cycle", command=self.detect_directed_cycle).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Reset Colors", command=self.reset_colors).pack(side=tk.LEFT, padx=5)

        self.info_label = tk.Label(self, text="")
        self.info_label.pack(pady=5)

        self.draw_graph()

    def draw_graph(self):
        self.canvas.delete("all")
        self.vertex_positions.clear()
        self.vertex_circles.clear()
        self.edge_lines.clear()

        vertices = list(self.graph.graph.keys())
        n = len(vertices)
        if n == 0:
            return

        angle_gap = 360 / n
        cx, cy = self.center

        for i, vertex in enumerate(vertices):
            angle = math.radians(i * angle_gap)
            x = cx + self.spacing * math.cos(angle)
            y = cy + self.spacing * math.sin(angle)

            self.vertex_positions[vertex] = (x, y)

            circle_id = self.canvas.create_oval(
                x - self.node_radius, y - self.node_radius,
                x + self.node_radius, y + self.node_radius,
                fill="lightblue", outline="black", width=2
            )
            self.vertex_circles[vertex] = circle_id
            self.canvas.create_text(x, y, text=vertex, font=("Arial", 12, "bold"))

        for vertex in vertices:
            x1, y1 = self.vertex_positions[vertex]
            for neighbor in self.graph.graph[vertex]:
                x2, y2 = self.vertex_positions[neighbor]

                dx, dy = x2 - x1, y2 - y1
                dist = math.sqrt(dx * dx + dy * dy)
                if dist == 0:
                    continue

                offset_x = dx / dist * self.node_radius
                offset_y = dy / dist * self.node_radius

                start_x = x1 + offset_x
                start_y = y1 + offset_y
                end_x = x2 - offset_x
                end_y = y2 - offset_y

                if self.graph.directed:
                    line_id = self.canvas.create_line(start_x, start_y, end_x, end_y, arrow=tk.LAST, width=2)
                else:
                    line_id = self.canvas.create_line(start_x, start_y, end_x, end_y, width=2)

                self.edge_lines[(vertex, neighbor)] = line_id

                if self.graph.weighted:
                    weight = self.graph.weights.get((vertex, neighbor), "")
                    mid_x = (start_x + end_x) / 2
                    mid_y = (start_y + end_y) / 2
                    self.canvas.create_text(mid_x, mid_y, text=str(weight), fill="red")

    def reset_colors(self):
        for circle_id in self.vertex_circles.values():
            self.canvas.itemconfig(circle_id, fill="lightblue")
        for line_id in self.edge_lines.values():
            self.canvas.itemconfig(line_id, fill="black", width=2)
        self.info_label.config(text="")
        self.update()

    def highlight_vertex(self, vertex, color):
        if vertex in self.vertex_circles:
            self.canvas.itemconfig(self.vertex_circles[vertex], fill=color)
            self.update()

    def highlight_edge(self, v1, v2, color):
        if (v1, v2) in self.edge_lines:
            self.canvas.itemconfig(self.edge_lines[(v1, v2)], fill=color, width=3)
            self.update()

    def run_bfs(self):
        self.reset_colors()
        start = 'A' if 'A' in self.graph.graph else next(iter(self.graph.graph))
        visited = []
        queue = [start]

        self.info_label.config(text="Running BFS...")
        while queue:
            vertex = queue.pop(0)
            if vertex not in visited:
                visited.append(vertex)
                self.highlight_vertex(vertex, "orange")
                self.info_label.config(text=f"BFS visiting: {vertex}")
                time.sleep(0.5)

                for neighbor in self.graph.graph[vertex]:
                    if neighbor not in visited and neighbor not in queue:
                        queue.append(neighbor)
                        self.highlight_edge(vertex, neighbor, "green")
                        time.sleep(0.2)

        self.info_label.config(text=f"BFS complete: {visited}")

    def run_dfs(self):
        self.reset_colors()
        start = 'A' if 'A' in self.graph.graph else next(iter(self.graph.graph))
        visited = []
        stack = [start]

        self.info_label.config(text="Running DFS...")
        while stack:
            vertex = stack.pop()
            if vertex not in visited:
                visited.append(vertex)
                self.highlight_vertex(vertex, "yellow")
                self.info_label.config(text=f"DFS visiting: {vertex}")
                time.sleep(0.5)

                for neighbor in reversed(self.graph.graph[vertex]):
                    if neighbor not in visited:
                        stack.append(neighbor)
                        self.highlight_edge(vertex, neighbor, "blue")
                        time.sleep(0.2)

        self.info_label.config(text=f"DFS complete: {visited}")

    def detect_undirected_cycle(self):
        self.reset_colors()
        has_cycle = self.graph.has_undirected_cycle()
        if has_cycle:
            self.info_label.config(text="Undirected cycle detected")
            for vertex in self.graph.graph:
                self.highlight_vertex(vertex, "pink")
        else:
            self.info_label.config(text="No undirected cycle found")

    def detect_directed_cycle(self):
        self.reset_colors()

        visited = set()
        rec_stack = set()

        def dfs(vertex):
            visited.add(vertex)
            rec_stack.add(vertex)
            self.highlight_vertex(vertex, "violet")
            time.sleep(0.4)

            for neighbor in self.graph.graph[vertex]:
                self.highlight_edge(vertex, neighbor, "red")
                time.sleep(0.2)

                if neighbor not in visited:
                    if dfs(neighbor):
                        return True
                elif neighbor in rec_stack:
                    return True

            rec_stack.remove(vertex)
            return False

        for vertex in self.graph.graph:
            if vertex not in visited:
                if dfs(vertex):
                    self.info_label.config(text="Directed cycle detected")
                    return

        self.info_label.config(text="No directed cycle found")


if __name__ == "__main__":
    g = Graph(directed=True, weighted=True)

    for vertex in ["A", "B", "C", "D"]:
        g.add_vertex(vertex)

    g.add_edge("A", "B", 10)
    g.add_edge("B", "C", 20)
    g.add_edge("C", "A", 30)
    g.add_edge("C", "D", 40)

    app = GraphVisualizer(g)
    app.mainloop() 