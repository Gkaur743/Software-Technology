from collections import deque

q = deque([10, 20, 30, 40, 50])

q.popleft()

print("Queue after dequeue:", list(q)) 